class helloWorld {
    public static void main(String[] args) {
        //Name, Year Up Site, Career Goal, Age, Brief Introduction
        System.out.println("Name: Dalemar");
        System.out.println("Year-Up Site: Pittsburgh");
        System.out.println("Career Goal: My goal career wise to have a nice technology based job and proffesion, that will not only allow me to learn more that I can apply to my hobbies. But also allow me to learn more about the technology of the world. That and I have a keen intrest in tech aswell.");
        //Weird you have age after career goal, test for comments      
        System.out.println("Age: 18");
        System.out.println("Brief Introduction: Ey my name is Dale, Im fresh outta High School and Im currently broke. Intrests: Horror, Games, Horror Games (in that order). Call Me");
    }
}